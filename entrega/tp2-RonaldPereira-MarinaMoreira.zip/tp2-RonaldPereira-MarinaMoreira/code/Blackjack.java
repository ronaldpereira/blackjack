public class Blackjack // Classe principal do jogo
{
    public static void main(String[] args) throws Exception
    {
        jogo.JogaJogo jogajogo = new jogo.JogaJogo(); // Cria um novo objeto do tipo JogaJogo, que esta no pacote jogo
        jogajogo.jogo(); // Chama o metodo que executa o jogo
    }
}
